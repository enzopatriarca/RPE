<!DOCTYPE html>
<html  lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Lista de Logs</title>

        <!-- Fonts -->
        <script type="text/javascript" src="<?php echo e(asset('jquary/jquery-3.6.0.min.js')); ?>"></script>
        
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('DataTables/datatables.min.css')); ?>" rel="stylesheet" />
        <script type="text/javascript" src="<?php echo e(asset('DataTables/datatables.min.js')); ?>"></script>

        <!--bootstrap-->
        
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/bootstrap/bootstrap.min.css')); ?>" rel="stylesheet" />
       
        <link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet" />

        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('jquaryUI/jquery-ui.min.css')); ?>" rel="stylesheet" />
        <script type="text/javascript" src="<?php echo e(asset('jquaryUI/jquery-ui.min.js')); ?>"></script>

        <!-- Styles -->

        <style>
            html, body {
                background-color: white;
                color: black;
            }


            
        </style>

        <?php if(Auth::check()): ?>
        <?php	
            $user = Auth::user();
        ?>
        <?php else: ?> 
        <script>window.location = "/RPE/public/"</script>
        <?php endif; ?>
        
    </head>
    <body >
        <div class="container-fluid">
                <div class="row flex-nowrap">
                    <div class="col-auto col-md-3 col-xl-2 px-sm-2 px-0 bg-dark">
                        <div class="d-flex flex-column align-items-center align-items-sm-start px-3 pt-2 text-white min-vh-100">
                            <ul class="nav nav-pills flex-column mb-sm-auto mb-0 align-items-center align-items-sm-start" id="menu">
                            
                            <div class="dropdown pb-4">
                                <a href="" class="d-flex align-items-center text-white text-decoration-none dropdown-toggle" id="dropdownUser1" data-bs-toggle="dropdown" aria-expanded="false">
                                    <?php if(Auth::check()): ?>
                                        <?php	
                                            $user = Auth::user();
                                        ?>
                                        <h3 class="usuario_log">Usuario: <?php echo e($user->name); ?></h3> 
                                        
                                    <?php else: ?> 
                                        <script>window.location = "/RPE/public/"</script>
                                    <?php endif; ?>
                                </a>
                                <ul class="dropdown-menu dropdown-menu-dark text-small shadow">
                                    <li><a  class="dropdown-item" href="<?php echo e(url('/logout')); ?>">Sair</a></li>
                                </ul>
                            </div>
                                <hr>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('dashboard')): ?> 
                                    <li  class="nav-item">
                                        <a href="<?php echo e(url('/dashboard')); ?>" class="nav-link align-middle px-0">
                                            <img class="icone" src = "/imgs/house.svg" alt=""/>
                                        
                                            <span style="color: white" class="ms-1 d-none d-sm-inline">Dashboard</span>
                                        </a>
                                    </li>
                                <?php endif; ?>
                                
                                    <li>
                                            <a href="<?php echo e(url('/registro_atividade')); ?>"  class="nav-link px-0 align-middle">
                                            <img class="icone" src = "/imgs/book.svg" alt=""/></i> <span style="color: white" class="ms-1 d-none d-sm-inline">Registrar Atividades</span> </a>
                                    </li>
                                
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('permissao_de_pagina_adm_super')): ?>
                                    <li>
                                            <a href="<?php echo e(url('/registro')); ?>" class="nav-link px-0 align-middle">
                                            <img class="icone" src = "/imgs/person-plus-fill.svg" alt=""/><span style="color: white" class="ms-1 d-none d-sm-inline">Registrar usuario</span></a>                                                                     
                                    </li>
                                <?php endif; ?>
                                <li>
                                    <a href="<?php echo e(url('/Atividades')); ?>" class="nav-link px-0 align-middle">
                                    <img class="icone" src = "/imgs/list.svg" alt=""/><span style="color: white" class="ms-1 d-none d-sm-inline"> Listar Atividades</span> </a>
                                </li>
                                <li>
                                    <a href="<?php echo e(url('/pdf_minhas_atividades')); ?>" class="nav-link px-0 align-middle">
                                    <img class="icone" src = "/imgs/file-earmark-pdf.svg" alt=""/><span style="color: white" class="ms-1 d-none d-sm-inline"> Gerar pdf</span> </a>
                                </li>
                                <li>
                                    <a href="<?php echo e(url('/logout')); ?>" class="nav-link px-0 align-middle">
                                    <img class="icone" src = "/imgs/box-arrow-left.svg" alt=""/> <span style="color: white" class="ms-1 d-none d-sm-inline">Sair</span> </a>
                                </li>
                            </ul>
                            <hr>
                        </div>
                    </div>
                    
               
                <div class="container">
                    <div class="row">
                        <div class="col-md-10">
                            <h2>Lista de Logs</h2>
                            <br>
                            <div class="card">
                                <table id="locais" class="table display" >
                                    <thead>
                                        <tr>
                                            <td>Id do Usuario</td>
                                            <td>Nome do usuario</td>
                                            <td>Nome da Operação</td>
                                            <td>Data Log</td>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($log->id_user); ?></td>
                                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($user->id == $log->id_user): ?>
                                                    <td><?php echo e($user->name); ?></td>
                                                    <?php endif; ?>   
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <td><?php echo e($log->nome_operacao); ?></td>
                                                <td><?php echo e($log->created_at); ?></td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>  
                            </div>    
                        </div>
                    </div>      
                </div>
                
                <script>
                    $(document).ready( function () {
                        $('#locais').DataTable();
                    } );
                </script>
        </div>
    
    </body>
</html>
<?php /**PATH /var/www/html/RPE/resources/views/Listar_logs.blade.php ENDPATH**/ ?>