<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Motivo Reprovação</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@200;600&display=swap" rel="stylesheet">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
        
        <link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet" />


        <!-- Styles -->
        <style>
            html, body {
                background-color: white;
                color: black;
     
            }
        </style>
    </head>
    <body>
    <div class="text-center">

        <img class="mt-4 mb-4" src="https://upload.wikimedia.org/wikipedia/commons/thumb/e/ea/Logo_Itaipu_Preferencial.svg/1200px-Logo_Itaipu_Preferencial.svg.png" height="80px" alt="Logo_Itaipu">
            <h1 class="titulo_1">RPE</h1>
            <h3 class="log">Motivo Reprovação</h3>
            <form style="width: 500px; margin:auto;" method="POST" action="<?php echo e(route('registro.motivo',['id'  => $atividade->id])); ?>">
                <?php if(session('message')): ?>
                <div class="alert alert-danger">
                    <?php echo e(session('message')); ?>

                </div>
                <?php endif; ?> 
                <?php echo csrf_field(); ?>
                
                <div class="mt-4">
                    <input style="border-color: black;" value="<?php echo e(old('motivo')); ?>" type="text" class="form-control" size="10px" id="motivo" placeholder="Motivo da Reprovação" name="motivo">
                </div>
                <?php if($errors->first('motivo')): ?>
                <div style="margin-top: 10px" class="alert-danger"><?php echo e($errors->first('motivo')); ?></div>
                <?php endif; ?>


                <div class=" mt-3">
                    <button class="btn_1" class="btn btn-lg btn-primary"> Mandar e-mail Reprovação </button>

                </div>

            </form>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    </body>
</html>
<?php /**PATH /var/www/html/RPE/resources/views/motivo_rpv_dash.blade.php ENDPATH**/ ?>