<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/bootstrap/bootstrap.min.css')); ?>" rel="stylesheet" />
       
    <link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet" />
    <title>PDF Atividades</title>
    
</head>
<body>
    
    <?php for($i = 0; $i < count($atividades_); $i++): ?>
        <div style="display: flex; ">
            <img style="width:100px; heigth:100px" src="imgs/logo.png" alt="">
            <p style="display: inline-flex;color:black;font-size: 22px;font-weight: bold;">REGISTRO PERIÓDICO DE EXECUÇÃO DE TRABALHOS COM RISCO ELÉTRICO &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; MES REF:<?php echo e($monthName); ?>/<?php echo e($ano); ?></p>
            
        </div>
    
        <table style="border: 1px solid black;font-size: 25px;">
            <thead style="border: 1px solid black;">
                <tr>
                    <td style="width: 600px; border: 1px solid black;"> <b>Nome:</b> <small><?php echo e($users_[$i]->nome); ?></small> </td>
                    <td style="width: 445px;border: 1px solid black;"><b>Matricula:</b> <small style="color: red"><?php echo e($users_[$i]->matricula); ?></small></td>
                    <td style="width: 445px;border: 1px solid black;"><b>Autorização:</b>  <small style="color: red"><?php echo e($users_[$i]->autorizacao); ?></small> </td>
        
        
                </tr>
            </thead>


        </table>

        <table style="border: 1px solid black;font-size: 25px;">
            <thead style="border: 1px solid black;">
                <tr>
                    <td style="width: 600px; border: 1px solid black;"><b>Cargo:</b>  <?php echo e($users_[$i]->cargo); ?> </td>
                    <td style="width: 893px;border: 1px solid black;"><b>Lotação:</b>  <small style="color: red"><?php echo e($users_[$i]->Lotacao); ?></small>  </td>        
                </tr>
            </thead>

        </table>

        <br>
        <br>
        <table style="border: 1px solid black;">
            <thead style="border: 1px solid black;">
                <tr style="text-align: center">
                    <td style="width: auto; border: 1px solid black;font-size: 21px;font-weight: bold;background-color: lightgrey;">Dia(s)</td>
                    <td style="width: auto;border: 1px solid black;font-size: 21px;font-weight: bold;background-color: lightgrey;">Natureza(S) de Atividade</td>
                    <td style="width: auto;border: 1px solid black;font-size: 21px;font-weight: bold;background-color: lightgrey;">Área(S) de Risco</td>
                    <td style="width: auto;border: 1px solid black;font-size: 21px;font-weight: bold;background-color: lightgrey;">Local (S)</td>
                    <td style="width: auto;border: 1px solid black;font-size: 21px;font-weight: bold;background-color: lightgrey;">Descrição da Atividade</td>
                    <td style="width: auto;border: 1px solid black;font-size: 21px;font-weight: bold;background-color: lightgrey;">Visto do Supervisor ou Gerente</td>
                </tr>
            </thead>
                <?php $__currentLoopData = $atividades_[$i]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $atividade): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tbody>
                        <tr>  
                            <td style="width: 115px;border: 1px solid black;font-size: 21px;"><?php echo e($atividade->dias); ?></td>  
                            <td style="width: 110px;border: 1px solid black;font-size: 21px;text-align: center"><?php echo e($atividade->tags_natureza); ?></td>
                            <td style="width: 150px;border: 1px solid black;font-size: 21px;text-align: center"><?php echo e($atividade->tags_area); ?></td>
                            <td style="width: 260px;border: 1px solid black;font-size: 21px;"><?php echo e($atividade->tags_locais); ?></td>

                            <td style="width: 640px;border: 1px solid black;font-size: 21px;"><?php echo e($atividade->descricao); ?></td>
                            <td style="width: 115px;border: 1px solid black;font-size: 21px;text-align: center"><?php echo e($atividade->gerente); ?></td>  
                        </tr>
                    </tbody>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
        <br>
        <br>
        <br>
        <table>
            <thead>
                <tr>
                    <td style="width: 500px; border: 1px solid black;font-weight: bold;background-color: lightgrey;">Assinatura:</td>
                    <td style="width: auto;border: 1px solid black;font-weight: bold;background-color: lightgrey;">Natureza da Atividade:</td>
                    <td style="width: auto;border: 1px solid black;font-weight: bold;background-color: lightgrey;">Áreas de Risco:</td>
                </tr>
            </thead>
            <tbody>
                <tr style="">
                    <td style="width: auto;border: 1px solid black;text-align: center">
                        <p>___________________________ ___/___/____</p>
                        <p>Gerente Imediato</p>
                    </td>
                    <td style="width: auto;border: 1px solid black;">
                        <?php $__currentLoopData = $naturezas_; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $natureza): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <p style="color: black"><?php echo e($natureza->id); ?>.<?php echo e($natureza->nome_natureza); ?></p>          
            
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </td>
                    <td style="width: auto;border: 1px solid black;">
                        <?php $__currentLoopData = $areas_; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $area): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <p><?php echo e($area->id); ?>.<?php echo e($area->nome_area); ?></p>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </td>
                </tr>
            </tbody>
        </table>
        <br>
        <br>
        <div class="page_break"></div>    
    <?php endfor; ?>   
   
    <script type="text/javascript" src="<?php echo e(asset('bootstrap/bootstrap.min.js')); ?>"></script>
</body>
</html><?php /**PATH /var/www/html/RPE/resources/views/pdfs_usuarios.blade.php ENDPATH**/ ?>