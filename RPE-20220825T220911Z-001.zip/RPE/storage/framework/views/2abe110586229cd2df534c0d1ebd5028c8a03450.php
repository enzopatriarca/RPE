<h1>Atividade de Risco</h1>
<h3>Sr. <?php echo e($supervisor); ?></h3>
<h3>Bom Dia.</h3>

<table style="border: 1px solid black;font-size: 16px;">
    <thead style="border: 1px solid black;">
        <tr>
            <td style="width: auto; border: 1px solid black;">Dia(S)</td>
            <td style="width: auto;border: 1px solid black;">Natureza(S) de Atividade</td>
            <td style="width: auto;border: 1px solid black;">Área(S) de Risco</td>
            <td style="width: auto;border: 1px solid black;">Local (S)</td>
            <td style="width: auto;border: 1px solid black;">Descrição da Atividade</td>
            <td style="width: auto;border: 1px solid black;">Supervisor</td>

        </tr>
    </thead>
    <tbody>
        <tr>
            <td style="width: auto;border: 1px solid black;"><?php echo e($dias); ?></td>
            <td style="width: auto;border: 1px solid black;"><?php echo e($naturezas_); ?></td>
            <td style="width: auto;border: 1px solid black;"><?php echo e($areas_); ?></td>
            <td style="width: auto;border: 1px solid black;"><?php echo e($locais_); ?></td>
            <td style="width: auto;border: 1px solid black;"><?php echo e($atividade->descricao); ?></td>
            <td style="width: auto;border: 1px solid black;"><?php echo e($supervisor); ?></td>
        </tr>
    </tbody>
</table>


<h3>Participantes:</h3>
<?php $__currentLoopData = $participantes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $participante): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <p style="margin: 0px;font-size: 16px;"><?php echo e($participante); ?></p>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<h3>LINK DE APROVAÇÃO: <?php echo e(url("http://192.168.3.1/RPE/public/validacao/{$hash_aprv}/{$atividade->id}")); ?> </h3>

<h3>LINK DE REPROVAÇÃO: <?php echo e(url("http://192.168.3.1/RPE/public/validacao/{$hash_rprv}/{$atividade->id}")); ?></h3>







<?php /**PATH /var/www/html/RPE/resources/views/emailteste.blade.php ENDPATH**/ ?>