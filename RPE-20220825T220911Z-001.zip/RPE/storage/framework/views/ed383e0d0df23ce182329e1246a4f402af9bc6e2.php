<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Loggin</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@200;600&display=swap" rel="stylesheet">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

        <!-- Styles -->
        <style>
            html, body {
                background-color: darkgrey;
                color: #636b6f;
                font-family: 'Nunito', sans-serif;
                font-weight: 200;
                height: 100vh;
                margin: 0;
            }

            .full-height {
                height: 100vh;
            }

            .flex-center {
                align-items: center;
                display: flex;
                justify-content: center;
            }

            .position-ref {
                position: relative;
            }

            .top-right {
                position: absolute;
                right: 10px;
                top: 18px;
            }

            .content {
                text-align: center;
            }

            .title {
                font-size: 84px;
            }

            .links > a {
                color: #636b6f;
                padding: 0 25px;
                font-size: 13px;
                font-weight: 600;
                letter-spacing: .1rem;
                text-decoration: none;
                text-transform: uppercase;
            }

            .m-b-md {
                margin-bottom: 30px;
            }
        </style>
    </head>
    <body>
    <div class="text-center">

    <img class="mt-4 mb-4" src="https://upload.wikimedia.org/wikipedia/commons/thumb/e/ea/Logo_Itaipu_Preferencial.svg/1200px-Logo_Itaipu_Preferencial.svg.png" height="80px" alt="Logo_Itaipu">
        <h1 class="titulo_1">RPE</h1>
        <h3 class="log">LOGGIN</h3>

    <form style="width: 500px; margin:auto;" method="POST" action="">
     
        <?php echo csrf_field(); ?>
        
        <div class="mt-4">
            <label class="titulo_2" for="Username"> Digite o usuario:</label>
            <input style="border-color: black;" type="text" class="form-control" size="10px" id="username" placeholder="Username" name="username">
        </div>
        


        <div class="mt-4">
            <label class="titulo_2" for="pass">Digite a senha</label>

                <input style="border-color: black;" type="password" class="form-control" size="10px" id="password" placeholder="password" name="password">                           
        </div>

        <div class=" mt-3">
            <button class="btn_1" class="btn btn-lg btn-primary">Sign in </button>

        </div>


    </form>
    </div>    


    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    </body>
</html>
<?php /**PATH /var/www/html/RPE/resources/views/welcome.blade.php ENDPATH**/ ?>