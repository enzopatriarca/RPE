<!DOCTYPE html>
<html  lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Lista de Atividades Participante</title>

        <!-- Fonts -->
        <script src="https://code.jquery.com/jquery-3.6.0.js" integrity="sha256-H+K7U5CnXl1h5ywQfKtSj8PCmoN9aaq30gDh27Xc0jk=" crossorigin="anonymous"></script>
        <script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.12.0/js/jquery.dataTables.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
        
        <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@200;600&display=swap" rel="stylesheet">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css">
        <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.12.0/css/jquery.dataTables.css">
        <link rel="stylesheet" type="text/css" href="css/style.css">

        <!-- Styles -->

        <style>
            html, body {
                background-color: white;
                color: black;
            }


            
        </style>

        <?php if(Auth::check()): ?>
        <?php	
            $user = Auth::user();
        ?>
        <?php else: ?> 
        <script>window.location = "/RPE/public/"</script>
        <?php endif; ?>
        
    </head>
    <body >
        <div class="container-fluid">
                <div class="row flex-nowrap">
                            <div class="col-auto col-md-3 col-xl-2 px-sm-2 px-0 bg-dark">
                                <div class="d-flex flex-column align-items-center align-items-sm-start px-3 pt-2 text-white min-vh-100">
                                    <ul class="nav nav-pills flex-column mb-sm-auto mb-0 align-items-center align-items-sm-start" id="menu">
                                    
                                    <div class="dropdown pb-4">
                                        <a href="" class="d-flex align-items-center text-white text-decoration-none dropdown-toggle" id="dropdownUser1" data-bs-toggle="dropdown" aria-expanded="false">
                                            <?php if(Auth::check()): ?>
                                                <?php   
                                                    $user = Auth::user();
                                                ?>
                                                <h3  class="usuario_log">Usuario: <?php echo e($user->name); ?></h3> 
                                                
                                            <?php else: ?> 
                                                <script>window.location = "/RPE/public/"</script>
                                            <?php endif; ?>
                                        </a>
                                        <ul class="dropdown-menu dropdown-menu-dark text-small shadow">
                                            <li><a class="dropdown-item" href="<?php echo e(url('/logout')); ?>">Sair</a></li>
                                        </ul>
                                    </div>
                                        <hr>
                                        <li class="nav-item">
                                            <a href="<?php echo e(url('/dashboard')); ?>" class="nav-link align-middle px-0">
                                                <i class="bi bi-house"></i>
                                            
                                                <span class="ms-1 d-none d-sm-inline">Dashboard</span>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#submenu1" data-bs-toggle="collapse" class="nav-link px-0 align-middle">
                                            <i class="bi bi-book"></i></i> <span class="ms-1 d-none d-sm-inline">Registrar Atividades</span> </a>
                                        </li>
                                        <li>
                                            <a href="<?php echo e(url('/registro')); ?>" class="nav-link px-0 align-middle">
                                            <i class="bi bi-person-plus-fill"></i><span class="ms-1 d-none d-sm-inline">Registrar usuario</span></a>
                                                
                                        </li>
                                        <li>
                                            <a href="#submenu2" data-bs-toggle="collapse" class="nav-link px-0 align-middle ">
                                            <i class="bi bi-list-stars"></i><span class="ms-1 d-none d-sm-inline">Listar Atividades</span></a>
                                            <ul class="collapse nav flex-column ms-1" id="submenu2" data-bs-parent="#menu">
                                                <li class="w-100">
                                                    <a href="#" class="nav-link px-0"> <span class="d-none d-sm-inline">Participante</span> </a>
                                                </li>
                                                <li>
                                                    <a href="#" class="nav-link px-0"> <span class="d-none d-sm-inline">Criador</span> </a>
                                                </li>
                                            </ul>
                                        </li>
                                        <li>
                                            <a href="#" class="nav-link px-0 align-middle">
                                            <i class="bi bi-file-earmark-pdf"></i><span class="ms-1 d-none d-sm-inline"> Gerar pdf</span> </a>
                                        </li>
                                        <li>
                                            <a href="<?php echo e(url('/logout')); ?>" class="nav-link px-0 align-middle">
                                            <i class="bi bi-box-arrow-left"></i></i> <span class="ms-1 d-none d-sm-inline">Sair</span> </a>
                                        </li>
                                    </ul>
                                    <hr>
                                </div>
                            </div>
                    
               
                <div class="container">
                    <div class="row">
                        <div class="col-md-10">
                            <h2>Lista de Atividades Participante</h2>
                            <br>
                            <div class="card">
                                <table id="locais" class="table display" >
                                    <thead>
                                        <tr>
                                            <td>Id</td>
                                            <td>Data Inicio</td>
                                            <td>Data Final</td>
                                            <td>Descrição</td>
                                            <td>Supervisor</td>

                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $atividades_; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $atividade): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($atividade->id); ?></td>
                                                <td><?php echo e($atividade->data_inicio); ?></td>
                                                <td><?php echo e($atividade->data_final); ?></td>
                                                <td><?php echo e($atividade->descricao); ?></td>
                                                <td><?php echo e($atividade->gerente); ?></td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>  
                            </div>    
                        </div>
                    </div>      
                </div>
                
                <script>
                    $(document).ready( function () {
                        $('#locais').DataTable();
                    } );
                </script>
        </div>
    
    </body>
</html>
<?php /**PATH /var/www/html/RPE/resources/views/Listar_Atv_participantes.blade.php ENDPATH**/ ?>